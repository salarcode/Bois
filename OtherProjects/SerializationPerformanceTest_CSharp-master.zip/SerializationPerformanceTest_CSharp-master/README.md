SerializationPerformanceTest_CSharp
===================================

The code for a serialization performance test in my blog post -

http://maxondev.com/serialization-performance-comparison-c-net-formats-frameworks-xmldatacontractserializer-xmlserializer-binaryformatter-json-newtonsoft-servicestack-text/


This code let you test performance of any serialization framework easily.
