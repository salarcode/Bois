using System;
namespace HelloWorldApp.BusinessObjects
{
    [Serializable]
    public struct AdvancedStruct
    {
        public int SimpleInt { get; set; }
        public string SimpleText { get; set; }
        public DateTime DateTime { get; set; }
    }
}